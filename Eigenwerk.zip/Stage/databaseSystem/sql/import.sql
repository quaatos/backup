DROP DATABASE IF EXISTS `databaseSystem`;
CREATE DATABASE `databaseSystem`;
USE `databaseSystem`;

CREATE TABLE `users` (
  id MEDIUMINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  age INT,
  Email VARCHAR(100)
);