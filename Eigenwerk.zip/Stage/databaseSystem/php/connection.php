<?php
try {
    $database = new PDO('mysql:host=localhost;dbname=databasesystem', 'root', '');
} catch (PDOException $e) {
    echo "Something went wrong!";
}
?>