<?php
session_start();
include_once('connection.php');//if you run this script on a real server you have to change the host to your server adres.

if (isset($_POST['submit'])) {
    $submit = $_POST['submit'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $age = $_POST['age'];
    $email = $_POST['email'];

    $fetchQuery = "SELECT * FROM users";
    $fetchData = $database->query($fetchQuery);
    $fetch = $fetchData->fetchAll();

//if fields are empty: do nothing
    if ($submit) {
        if (!empty($username) && !empty($password)) {
            try {
                $sql = "INSERT INTO `users` (`name`, `password`, `age`, `email`) VALUES (:user, :pass, :age, :email)";
                $query = $database->prepare($sql);
                $query->bindParam(':user', $username, PDO::PARAM_STR);
                $query->bindParam(':pass', $password, PDO::PARAM_STR);
                $query->bindParam(':age', $age, PDO::PARAM_INT);
                $query->bindParam(':email', $email, PDO::PARAM_STR);
                $query->execute();
                header('Location: ../index.php?username=' . $username);
            } catch (Exception $e) {
                echo "Username '$username' is already taken.";
            }
        } else {
            echo "Fill in all fields!";  
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create account</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <h2>Create account</h2>
    <form action="createAccount.php" method="POST">
        <input type="text" name="username" placeholder="Username" require>
        <input type="password" name="password" placeholder="Password" require>
        <input type="number" name="age" placeholder="Age">
        <input type="text" name="email" placeholder="E-mail">
        <input type="submit" name="submit" value="CREATE ACCOUNT">
    </form>
    <b class="createAccountLink"><p>Already have an account? click <a href="../index.php">here!</a></p></b>
</body>
</html>