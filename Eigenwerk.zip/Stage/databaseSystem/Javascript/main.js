function confirmation() {
    let x = "";
    let confirm = confirm("Are you sure you want to delete this row?");

    if (confirm = true) {
        x = "Row deleted!";

    } else {
        x = "Row not deleted!";
    }
}
//IN PROGRESS: confirmation if you want to delete a row.