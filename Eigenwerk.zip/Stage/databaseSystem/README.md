# SQLdatabaseSystem 
Do something with it and maybe improve it.<br>
I'm using PHPMYADMIN

first release: April 9, 2022
--
_____________
April 14, 2022. [update]
--
Ordering table columns is now possible
_____________
April 21, 2022. Login system [update] V1.1
--
It's not possible to create an empty user.<br>
passwords will be stored as binary numbers in database [extreme secure]<br>
_____________
May 3, 2022. Login System [update] V1.2
--
It is now only possible to login with an existing account (Cost me a lost of work)
I'll find further exploits in the future. (Feel free to create a issue if you find one.)
I chanched the password storaged, i'll figure out how to encrpyt them later, Binary wasn't really save i guess :)
_____________
May 26, 2022. [Update]
--
It is now impossible to create an already existing user.<br>
also, password enryption in progress

_____________
December 3, 2022. [Update]
--
I updadet the whole program with full password encryption/decryption.<br>
Also i cleaned up some code, my skills bacn then weren't as clean as now. there is always space to improve :) Enjoy the newest release!