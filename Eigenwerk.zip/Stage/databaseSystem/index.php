<?php
session_start();
include_once('php/connection.php');

if (isset($_GET['username'])) {
    $username = $_GET['username'];
}

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $PlainPass = $_POST['password'];

    $sql = "SELECT * FROM `users` WHERE `name` = :name"; //select credentials of enterd users
    $query = $database->prepare($sql);
    $query->bindParam(':name', $username, PDO::PARAM_STR);
    $query->execute();
    $fetchAll = $query->fetch();
    if (!empty($fetchAll['password'])) {
        $fetchPass = $fetchAll['password'];
        $password = password_verify($PlainPass, $fetchPass);
    } else {
        echo "Something went wrong, check your spelling and try again.";
    }
    
    try {
        if (!empty($username) && !empty($password)) {
            if ($PlainPass == $password) {
                $_SESSION['user'] = $username;
                header("Location: php/index.php");
                die();
            }
        } else {
            $_SESSION['error'] = "Both fields are required!";
        }
    } catch (Exception $e) {
        echo "Username or Password is incorrect!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <h2>Login</h2>
    <form action="index.php" method="POST" autocomplete="off">
        <input type="text" name="username" placeholder="username" value="<?php if(isset($username)) { echo $username;}?>" require>
        <input type="password" name="password" placeholder="Password" require>
        <input type="submit" name="submit" value="LOGIN">
    </form>
    
    <b class="createAccountLink"><p>Want to create an account? click <a href="php/createAccount.php">here!</a></p></b>
</body>
</html>
